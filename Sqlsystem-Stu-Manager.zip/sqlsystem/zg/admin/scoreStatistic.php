<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>数据统计 >> 成绩统计</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .subtitle {
            margin-top: 20px;
            font-size: 24px;
            color: #333;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 80%;
            max-width: 600px;
            margin-top: 20px;
        }
        .inputbox {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
        }
        .inputbox span {
            flex-basis: 30%;
            text-align: right;
            margin-right: 10px;
            font-size: 16px;
            color: #333;
        }
        .inputbox input, .inputbox select {
            flex-basis: 60%;
            padding: 8px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .clickbox {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }
        .clickbox input {
            padding: 10px 20px;
            font-size: 16px;
            color: #fff;
            background-color: #117700;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s, box-shadow 0.3s;
        }
        .clickbox input:hover {
            background-color: #0d5d00;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }
        .clickbox input:active {
            background-color: #0a4500;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
        }
        .redbox input {
            background-color: #d9534f;
        }
        .redbox input:hover {
            background-color: #c9302c;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }
        .redbox input:active {
            background-color: #ac2925;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
        }
        iframe {
            margin-top: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .print-button {
            float: right;
            margin-right: 50px;
            font-size: 16px;
            color: #117700;
            cursor: pointer;
            transition: color 0.3s;
        }
        .print-button:hover {
            color: #0d5d00;
        }
    </style>
    <script>
        function printresult() {
            document.getElementsByName("resultbox")[0].contentWindow.print();
        }
    </script>
</head>
<body>
<a class="print-button" href="#" onclick="printresult()">打印</a>
<h3 class="subtitle">数据统计 >> 成绩统计</h3>
<form action="./fun/scoreStatistic.php" method="get" target="resultbox">
    <div class="inputbox"><span>学号：</span><input name="sid" type="text"></div>
    <div class="inputbox"><span>姓名：</span><input name="name" type="text"></div>
    <div class="inputbox"><span>班级：</span><input name="class" type="text"></div>
    <div class="inputbox"><span>院系：</span>
    <?php
    require_once '../config/database.php';
    echo '<select name="did"><option value="">全部</option>';
    $dept = mysqli_query($db, "select did, dname from department");
    while ($dr = mysqli_fetch_object($dept)) {
        echo '<option value="' . $dr->did . '"> ' . $dr->dname . '</option>';
    }
    echo '</select>';
    mysqli_close($db);
    ?></div>
    <br>
    <div class="clickbox">
        <input name="submit" type="submit" value="提交">
        <div class="redbox"><input name="reset" type="reset" value="清除"></div>
    </div>
</form>
<iframe name="resultbox" frameborder="0" width="100%" height="550px"></iframe>
</body>
</html>
