<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>学生管理信息系统</title>
    <!-- 内联CSS样式 -->
    <style>
        body {
            font-family: Arial, sans-serif; /* 设置整个页面的字体为Arial，如果Arial不可用则使用系统默认的无衬线字体 */
            margin: 0; /* 清除body的默认外边距，让内容贴紧浏览器边缘 */
            padding: 0; /* 清除body的默认内边距 */
            background-color: #f0f0f0; /* 设置页面背景色为浅灰色 */
            }
            h1 {
            text-align: center; /* 让所有h1标题居中显示 */
            padding: 50px 0; /* 上下内边距为50px，左右内边距为0，使得标题与内容之间有空间 */
            color: #333; /* 设置标题文字颜色为深灰色 */
        }
        ol {
            list-style-type: decimal; /* 使用数字作为列表项标记 */
            margin: 0 auto; /* 消除默认外边距并水平居中列表 */
            max-width: 600px; /* 设置列表的最大宽度为600px */
            padding: 0 20px; /* 左右内边距为20px，让内容与边界有间隔 */
            color: #666; /* 设置列表文字颜色为中灰色 */
        }
        li {
            margin-bottom: 15px;/* 在每个列表项底部添加15px的外边距，增加垂直间距 */
        }
        div {
    background-color: white; /* 设置div背景色为白色 */
    box-shadow: 0 2px 4px rgba(0,0,0,0.1); /* 添加一个轻微的阴影效果，提升视觉层次 */
    padding: 20px; /* 给div内的内容周围添加20px的内边距 */
    border-radius: 5px; /* 让div的边角变得圆滑 */
    margin: 30px auto; /* 设置上下外边距为30px，左右自动，实现居中 */
    max-width: 90%; /* 限制div的最大宽度为页面宽度的90% */
}
    </style>
</head>
<body>

<div>
    <h1>学生管理信息系统</h1>
    <ol>
        <li>课上学的C#和sqlserver开发,我用的phpstudy直接开发。</li>
        <li>要求系统可以准确地记录和查询学生信息，包括学生的姓名、单位、年龄、性别等。</li>
        <li>系统可以对学校的院系情况进行管理，包括设置学院名称、修改某学院某专业方向的名称等。</li>
        <li>系统能够对开设的课程进行管理</li>
        <li>学生选课管理、考试（登记分数）、补考重修管理</li>
        <li>系统还应该提供强大数据统计、查询、报表生成以及打印等功能。</li>
        <li>用户权限管理</li>
        <li>异常处理</li>
    </ol>
</div>

</body>
</html>