<?php

require_once("../../config/database.php");

$old = $_GET["mname"];
$new = $_GET["nname"];
$com = "UPDATE major SET mname='$new' WHERE mname='$old'";

$result = mysqli_query($db, $com);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>信息更新结果</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .message-box {
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .message-box h4 {
            margin-bottom: 20px;
            color: #333;
        }
        .back-button {
            width: 100px;
            padding: 10px;
            background-color: #117700;
            color: #f3f3f3;
            text-decoration: none;
            border-radius: 4px;
            display: inline-block;
            text-align: center;
        }
        .back-button:hover {
            background-color: #0e5f00;
        }
    </style>
</head>
<body>
    <div class="message-box">
        <?php if ($result): ?>
            <h4>提示：信息更改成功！</h4>
        <?php else: ?>
            <h4>注意：数据未更改！</h4>
        <?php endif; ?>
        <a class="back-button" href="#" onclick="javascript:history.back(-1);">返回</a>
    </div>
</body>
</html>
<?php
mysqli_close($db);
?>
