<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>院系信息</title>
    <link rel="stylesheet" type="text/css" href="./css/fun.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        .subtitle {
            color: #333;
            text-align: center;
            margin-top: 20px;
            font-size: 24px;
            font-weight: bold;
        }
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
            font-size: 18px;
            color: #333;
        }
        tr:hover {
            background-color: #f5f5f5;
        }
        a {
            color: #4CAF50;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h3 class="subtitle">院系管理 >> 院系列表</h3>
    <table>
        <tr>
            <th>院系序号</th>
            <th>院系名称</th>
            <th>所在地址</th>
            <th>负责人</th>
            <th>联系方式</th>
            <th>操作</th>
        </tr>
        <?php
        require_once("../config/database.php");
        $com='select * from department order by did';
        
        $result=mysqli_query($db,$com);
        if($result){
            while($row=mysqli_fetch_object($result)){
                ?>
                <tr>
                    <td><?php echo $row->did ?></td>
                    <td><?php echo $row->dname ?></td>
                    <td><?php echo $row->dadd ?></td>
                    <td><?php echo $row->dmng ?></td>
                    <td><?php echo $row->dtel ?></td>
                    <td><a href="./fun/modiDept.php?did=<?php echo $row->did; ?>">修改</a></td>
                </tr>
                <?php
            }
        }

        mysqli_close($db);
        ?>
    </table>
</body>
</html>
