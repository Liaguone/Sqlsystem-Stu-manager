<?php
require_once("../../config/database.php");

$sid = $_POST["sid"];
$name = $_POST["name"];
$sex = $_POST["sex"];
$age = $_POST["age"];
$class = $_POST["class"];
$did = $_POST["did"];
$idnum = $_POST["idnum"];

$com = "INSERT INTO student (sid, name, sex, age, class, did, idnum) VALUES ('$sid', '$name', '$sex', '$age', '$class', '$did', '$idnum')";

$pwd = md5(substr($sid, -6));
$com2 = "INSERT INTO user_student (sid, pwd) VALUES ('$sid', '$pwd')";

$result = mysqli_query($db, $com);
$result2 = mysqli_query($db, $com2);

$message = $result && $result2 ? "成功，同时已新建学生账户，密码为学号后六位" : "数据未更改。";

mysqli_close($db);
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>操作结果</title>
    <style>
        
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            text-align: center;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .message {
            font-size: 18px;
            color: #333;
            margin-bottom: 20px;
        }
        .back-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #117700;
            color: #f3f3f3;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .back-button:hover {
            background-color: #0d5d00;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="message"><?php echo $message; ?></div>
        <a class="back-button" href="javascript:history.back(-1);">返回</a>
    </div>
</body>
</html>
