<?php
require_once("../../config/database.php");
session_start();

if (!isset($_SESSION["admin"])) {
    echo "<div class='alert warning'>警告！非法访问！<br>Warning! Illegal Operation!</div>";
    exit();
}

$uid = $_SESSION["admin"];
$old = md5($_POST["oldpass"]);
$new = md5($_POST["newpass"]);

$com1 = "SELECT * FROM user_admin WHERE adminID='$uid' AND pwd='$old'";
$com2 = "UPDATE user_admin SET pwd='$new' WHERE adminID='$uid'";

$result1 = mysqli_query($db, $com1);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>密码更改</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .alert {
            margin: 20px;
            padding: 15px;
            border-radius: 4px;
            font-size: 18px;
        }
        .success {
            background-color: #4CAF50;
            color: white;
        }
        .warning {
            background-color: #ff9800;
            color: white;
        }
        .error {
            background-color: #f44336;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php
        if ($result1->num_rows > 0) { // User exists
            $result2 = mysqli_query($db, $com2);
            if ($result2) {
                echo '<div class="alert success">提示：密码更改成功。</div>';
            } else {
                echo '<div class="alert warning">注意：数据未更改！</div>';
            }
        } else {
            echo '<div class="alert error">注意：认证错误，数据未更改。请检查你的输入。</div>';
        }
        mysqli_close($db);
        ?>
    </div>
</body>
</html>
