<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>课程查询</title>
    
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        .subtitle {
            text-align: center;
            margin-top: 20px;
            font-size: 24px;
            font-weight: bold;
            color: #333;
        }
        form {
            width: 50%;
            margin: 20px auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .inputbox {
            margin: 15px 0;
            display: flex;
            align-items: center;
        }
        .inputbox span {
            display: inline-block;
            width: 120px;
            font-size: 16px;
            color: #333;
        }
        .inputbox input {
            width: calc(100% - 140px);
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .clickbox {
            text-align: center;
            margin-top: 20px;
        }
        .clickbox input[type="submit"],
        .clickbox input[type="reset"] {
            background-color: #4CAF50;
            color: white;
            padding: 12px 20px;
            margin: 8px 5px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .clickbox input[type="submit"]:hover,
        .clickbox input[type="reset"]:hover {
            opacity: 0.8;
        }
        .redbox input[type="reset"] {
            background-color: #f44336;
        }
        iframe {
            width: 90%;
            height: 550px;
            border: none;
            margin: 20px auto;
            border-radius: 4px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            display: block;
        }
    </style>
</head>
<body>
    <div class="subtitle">
        <h3>课程查询</h3>
    </div>
    <form action="./fun/getCourse.php" method="get" target="resultbox">
        <div class="inputbox"><span>课程号：</span><input name="cid" type="text"></div>
        <div class="inputbox"><span>课程名：</span><input name="cname" type="text"></div>
        <div class="inputbox"><span>学分：</span><input name="credit" type="text"></div>
        <div class="inputbox"><span>上课地址：</span><input name="caddr" type="text"></div>
        <div class="inputbox"><span>开课学院：</span><input name="dname" type="text"></div>
        <div class="inputbox"><span>教师姓名：</span><input name="tname" type="text"></div>
        <div class="clickbox clearfloat"><span></span><input name="submit" type="submit" value="提交"></div>
        <div class="clickbox redbox"><span></span><input name="reset" type="reset" value="清除"></div>
    </form>
    <iframe name="resultbox" frameborder="0"></iframe>
</body>
</html>
