<?php 
session_start();
if(!isset($_SESSION["admin"])||!$_SESSION["login"]==true){
        header ("HTTP/1.1 302 Moved Temporatily"); 
        header ("Location: "."../"); 
        exit();
    }
?>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/index.css">
    <title>学生信息管理系统@2024</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #e9ecef; /* 柔和的灰白色背景 */
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            color: #333; /* 全局字体颜色 */
        }

        .topnav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #343a40; /* 深灰色背景 */
            color: white;
            padding: 10px 20px; /* 增加左右内边距 */
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* 轻微阴影 */
            position: relative; /* 设置为相对定位 */
        }

        .topnav .logo {
            font-size: 24px;
            font-weight: bold;
            margin: 0 auto; /* 自动左右外边距使其居中 */
            text-align: center;
            flex: 1; /* 占据剩余空间 */
        }

        .topnav .userbox {
            font-size: 16px;
            margin-left: auto; /* 自动左外边距将其推到右侧 */
        }

        .topnav .userbox a {
            color: #ffc107; /* 金黄色的登出链接 */
            text-decoration: none;
            margin-left: 10px;
        }

        .navbar {
            display: flex;
            justify-content: center;
            background-color: #495057; /* 中灰色背景 */
            position: relative;
        }

        .navbar .navitem {
            margin: 0 15px;
            padding: 15px 20px; /* 增加内边距 */
            color: white;
            text-decoration: none;
            font-size: 18px;
            cursor: pointer;
            transition: background 0.3s, color 0.3s; /* 添加颜色渐变效果 */
        }

        .navbar .navitem:hover {
            background-color: #6c757d; /* 浅灰色背景 */
            color: #ffc107; /* 悬停时金黄色字体 */
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #495057;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.1);
            z-index: 1;
        }

        .dropdown-content a {
            color: white;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            transition: background 0.3s, color 0.3s;
        }

        .dropdown-content a:hover {
            background-color: #6c757d;
            color: #ffc107;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .container {
            width: 100%;
            padding: 20px;
            flex: 1; /* 使container撑满剩余空间 */
        }

        .content {
            margin-top: 20px;
        }

        .footer {
            text-align: center;
            padding: 20px;
            background-color: #343a40;
            color: #ffc107;
            border-top: 1px solid #495057; /* 增加顶部边框 */
        }

        iframe {
            width: 100%;
            height: calc(100vh - 200px); /* 调整高度 */
            border: none;
        }
    </style>
</head>
<body>
<div class="topnav">
    <div class="logo">
        学生信息管理系统
    </div>
    <div class="userbox">
        你好，Liagu <?php echo $_SESSION["admin"]?> <a href="../logout.php">登出</a>
    </div>
</div>
<div class="navbar">
    <a class="navitem" href="./welcome.php" target="frame">首页</a>
    <div class="dropdown">
        <div class="navitem">学生管理</div>
        <div class="dropdown-content">
            <a href="./addStudent.php" target="frame">新增学生</a>
            <a href="./queueStudent.php" target="frame">查询学生</a>
        </div>
    </div>
    <div class="dropdown">
        <div class="navitem">院系管理</div>
        <div class="dropdown-content">
            <a href="./queueDept.php" target="frame">院系信息</a>
            <a href="./queueMajor.php" target="frame">专业列表</a>
        </div>
    </div>
    <div class="dropdown">
        <div class="navitem">课程管理</div>
        <div class="dropdown-content">
            <a href="./queueCourse.php" target="frame">课程查询</a>
            <a href="./addCourse.php" target="frame">新增课程</a>
        </div>
    </div>
    <div class="dropdown">
        <div class="navitem">选课管理</div>
        <div class="dropdown-content">
            <a href="./queueChoose.php" target="frame">学生选课</a>
            <a href="./queueMark.php" target="frame">登记分数</a>
            <a href="./queueRetake.php" target="frame">补考重修</a>
        </div>
    </div>
    <div class="dropdown">
        <div class="navitem">数据统计</div>
        <div class="dropdown-content">
            <a href="./scoreStatistic.php" target="frame">成绩统计</a>
            <a href="./classStatistic.php" target="frame">选课统计</a>
        </div>
    </div>
    <div class="dropdown">
        <div class="navitem">系统设置</div>
        <div class="dropdown-content">
            <a href="./userManage.php" target="frame">用户管理</a>
            <a href="./changePassword.php" target="frame">修改密码</a>
        </div>
    </div>
</div>
<div class="container content">
    <iframe name="frame" frameborder="0" scrolling="yes" src="./welcome.php"></iframe>
</div>
<div class="footer">
    <span>数据库系统课程设计@2024</span>
</div>
</body>
</html>
