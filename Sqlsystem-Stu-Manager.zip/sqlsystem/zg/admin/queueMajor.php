<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <title>院系管理 >> 专业列表</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        .subtitle {
            color: #333;
            text-align: center;
            margin-top: 20px;
            font-size: 24px;
            font-weight: bold;
        }
        form {
            width: 50%;
            margin: 20px auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .inputbox {
            margin: 15px 0;
        }
        .inputbox span {
            display: inline-block;
            width: 80px;
            font-size: 16px;
            color: #333;
        }
        .inputbox select, .inputbox input {
            width: calc(100% - 100px);
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .clickbox {
            text-align: center;
            margin-top: 20px;
        }
        .clickbox input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 12px 20px;
            margin: 8px 0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .clickbox input[type="submit"]:hover {
            opacity: 0.8;
        }
        a {
            display: block;
            text-align: center;
            margin: 20px auto;
            font-size: 16px;
            color: #4CAF50;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        iframe {
            width: 80%;
            height: 500px;
            border: none;
            margin: 20px auto;
            border-radius: 4px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            display: block;
        }
    </style>
</head>
<body>
    <h3 class="subtitle">院系管理 >> 专业查询</h3>
    <form action="./fun/getMajor.php" method="get" target="resultbox">
        <div class="inputbox"><span>院系：</span>
        <?php
        require_once '../config/database.php';
        echo '<select name="did">';
        $dept=mysqli_query($db,"select did,dname from department");
        while($dr=mysqli_fetch_object($dept)) {
            echo '<option value="'.$dr->did.'" ';  echo '> '.$dr->dname.'</option>' ;
        }
        echo '</select>';
        mysqli_close($db);
        ?>
        </div>
        <div class="clickbox"><input name="submit" type="submit" value="提交"></div>
    </form>
    <a href="./fun/addMajor.php" target="resultbox">新增专业</a>
    <iframe name="resultbox"></iframe>
</body>
</html>
