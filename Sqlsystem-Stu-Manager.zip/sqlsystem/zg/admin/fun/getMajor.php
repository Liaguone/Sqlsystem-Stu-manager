<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>院系管理 >> 专业列表</title>
    <link rel="stylesheet" type="text/css" href="../css/fun.css">
    <script>
        function reName(mname){
            var nname = prompt("请输入要更改的名称", mname);
            if (nname) {
                window.location.href = "./editMajor.php?mname=" + mname + "&nname=" + nname;
            }
        }
    </script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
        }
        h3 {
            color: #333;
            font-size: 24px;
            text-align: center;
            margin-bottom: 20px;
        }
        ul {
            list-style-type: none;
            padding: 0;
            max-width: 600px;
            margin: 0 auto;
        }
        li {
            background: #fff;
            margin: 10px 0;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        a {
            font-size: 14px;
            color: #4CAF50;
            text-decoration: none;
            margin-left: 10px;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <?php
    require_once("../../config/database.php");

    $com = "SELECT * FROM major WHERE did='" . $_GET['did'] . "'";
    $result = mysqli_query($db, $com);
    if ($result) {
        echo ("<h3>当前开设的专业有：</h3><ul>");
        while ($row = mysqli_fetch_object($result)) {
            echo '<li>' . $row->mname . '<span><a href="#" onclick="reName(\'' . $row->mname . '\')">改</a><a href="./delMajor.php?mname=' . $row->mname . '">删</a></span></li>';
        }
        echo ("</ul>");
    } else {
        echo ("<h3>提示：你选择的学院当前没有开设专业</h3>");
    }

    mysqli_close($db);
    ?>

</body>
</html>
