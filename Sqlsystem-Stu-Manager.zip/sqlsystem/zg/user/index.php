<?php 
session_start();
if(!isset($_SESSION["user"])||!$_SESSION["login"]==true){
    header ("HTTP/1.1 302 Moved Temporatily"); 
    header ("Location: "."../"); 
    exit();
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="index.css">
    <title>学生选课信息管理系统</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #e9ecef; /* 柔和的灰白色背景 */
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            color: #333; /* 全局字体颜色 */
        }

        .topnav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #007bff; /* 蓝色背景 */
            color: white;
            padding: 10px 20px; /* 增加左右内边距 */
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* 轻微阴影 */
            position: relative; /* 设置为相对定位 */
        }

        .topnav .logo {
            font-size: 24px;
            font-weight: bold;
            color: #000; /* 加深字体颜色 */
            flex: 1;
            text-align: center;
        }

        .topnav .userbox {
            font-size: 16px;
            color: #000; /* 加深字体颜色 */
        }

        .topnav .userbox a {
            color: #ffc107; /* 金黄色的登出链接 */
            text-decoration: none;
            margin-left: 10px;
        }

        .navbar {
            display: flex;
            justify-content: center;
            background-color: #495057; /* 中灰色背景 */
            padding: 10px 0; /* 增加上下内边距 */
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* 轻微阴影 */
        }

        .navbar .navitem {
            margin: 0 15px;
            padding: 10px 20px; /* 增加内边距 */
            color: white;
            text-decoration: none;
            font-size: 18px;
            cursor: pointer;
            transition: background-color 0.3s, box-shadow 0.3s;
        }

        .navbar .navitem:hover {
            background-color: #343a40; /* 深灰色背景 */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* 轻微阴影 */
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f1f1f1;
            min-width: 160px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1;
            flex-direction: column;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown-content a:hover {
            background-color: #ddd;
        }

        .dropdown:hover .dropdown-content {
            display: flex;
        }

        .container {
            flex: 1;
            padding: 20px;
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            background-color: white;
            border-radius: 10px;
        }

        iframe {
            width: 100%;
            height: 80vh;
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .footer {
            background-color: #343a40;
            color: white;
            text-align: center;
            padding: 10px 0;
            box-shadow: 0 -2px 4px rgba(0, 0, 0, 0.1);
            margin-top: auto;
        }

        .footer span {
            font-size: 14px;
        }
    </style>
</head>
<body>
<div class="container topnav">
    <div class="logo">
        学生选课信息管理系统
    </div>
    <div class="userbox">
        当前用户：<?php echo $_SESSION["user"]?>  <a href="../logout.php">登出</a>
    </div>
</div>
<div class="navbar">
    <a class="navitem" href="./welcome.php" target="frame">首页</a>
    <div class="dropdown">
        <div class="navitem">个人信息</div>
        <div class="dropdown-content">
            <a href="./myInfo.php" target="frame">学籍信息</a>
            <a href="./editInfo.php" target="frame">修改信息</a>
        </div>
    </div>
    <div class="dropdown">
        <div class="navitem">选课管理</div>
        <div class="dropdown-content">
            <a href="./queueClass.php" target="frame">开课查询</a>
            <a href="./myClass.php" target="frame">选课管理</a>
        </div>
    </div>
    <div class="dropdown">
        <div class="navitem">成绩查询</div>
        <div class="dropdown-content">
            <a href="./myScore.php" target="frame">学科成绩</a>
            <a href="./myRetake.php" target="frame">重修管理</a>
        </div>
    </div>
    <div class="dropdown">
        <div class="navitem">奖惩管理</div>
        <div class="dropdown-content">
            <a href="./myLog.php" target="frame">奖惩查询</a>
            <a href="./addLog.php" target="frame">项目录入</a>
        </div>
    </div>
    <div class="dropdown">
        <div class="navitem">系统管理</div>
        <div class="dropdown-content">
            <a href="./editPass.php" target="frame">修改密码</a>
        </div>
    </div>
</div>
<div class="container content">
    <iframe name="frame" frameborder="0" src="./welcome.php"></iframe>
</div>
<div class="footer">
    <span>数据库系统课程设计@2019</span>
</div>
</body>
</html>
