<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="./css/userManage.css">
    <title>系统设置 &raquo; 用户管理</title>
</head>
<body>
    <header class="page-header">
        <h1>系统设置 &raquo; 用户管理</h1>
    </header>
    <section class="content">
        <p>提示：<strong>作为管理员</strong>，你可以激活学生账户，为学生账户重置密码。</p>
        <form action="./fun/getUser.php" method="get" target="resultbox">
            <div class="form-group">
                <label for="sid">学号：</label>
                <input id="sid" name="sid" type="text">
            </div>
            <div class="form-group">
                <label for="name">姓名：</label>
                <input id="name" name="name" type="text">
            </div>
            <div class="button-group">
                <input class="submit-btn" type="submit" value="提交">
                <input class="reset-btn" type="reset" value="清除">
            </div>
        </form>
    </section>
    <iframe class="result-iframe" name="resultbox" frameborder="0" width="100%" height="600"></iframe>
</body>
</html>