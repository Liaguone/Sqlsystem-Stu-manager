<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>学生成绩和学分信息</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 20px;
        }
        .titlebox {
            text-align: center;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            border-radius: 8px;
        }
        .titlebox h3 {
            margin: 0;
            font-size: 24px;
            color: #333;
        }
        .titlebox p {
            margin: 10px 0 0;
            color: #666;
        }
        table {
            width: 100%;
            margin: 0 auto;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #4CAF50;
            color: white;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        a {
            color: #4CAF50;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="titlebox">
            <h3>学生成绩和学分信息</h3>
            <p>在这里你可以查看学生的成绩和已修学分情况。</p>
        </div>
        <table>
            <tr>
                <th>学号</th>
                <th>姓名</th>
                <th>学院</th>
                <th>班级</th>
                <th>平均成绩</th>
                <th>已修学分</th>
                <th>操作</th>
            </tr>
            <?php
            require_once("../../config/database.php");

            $com = "SELECT * FROM
                    (SELECT sid, name, did, dname, class, sex, avg_score FROM
                    (SELECT sid, name, did, class, sex, avg_score FROM
                    (SELECT sid, AVG(score) AS avg_score
                    FROM student_course
                    WHERE status=0 AND score IS NOT NULL
                    GROUP BY sid) AS v1 NATURAL JOIN student) AS v2
                    NATURAL JOIN department) AS v3 NATURAL JOIN
                    (SELECT sid, SUM(credit) AS sum_credit FROM (SELECT sid, cid, credit FROM
                    (SELECT DISTINCT sid, cid FROM student_course WHERE score>60)
                    AS v4 NATURAL JOIN course) AS v5 GROUP BY sid) AS v6 WHERE 1=1";

            if (!empty($_GET['sid'])) {
                $com .= " AND sid LIKE '%" . $_GET['sid'] . "%'";
            }
            if (!empty($_GET['name'])) {
                $com .= " AND name LIKE '%" . $_GET['name'] . "%'";
            }
            if (!empty($_GET['class'])) {
                $com .= " AND class LIKE '%" . $_GET['class'] . "%'";
            }
            if (!empty($_GET['did'])) {
                $com .= " AND did LIKE '%" . $_GET['did'] . "%'";
            }

            $result = mysqli_query($db, $com);
            if ($result) {
                while ($row = mysqli_fetch_object($result)) {
                    echo "<tr>
                        <td>{$row->sid}</td>
                        <td>{$row->name}</td>
                        <td>{$row->dname}</td>
                        <td>{$row->class}</td>
                        <td>{$row->avg_score}</td>
                        <td>{$row->sum_credit}</td>
                        <td><a href='getStuScore.php?sid={$row->sid}'>成绩详情</a></td>
                    </tr>";
                }
            }

            mysqli_close($db);
            ?>
        </table>
    </div>
</body>
</html>
