<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>选课管理 >> 重修管理</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        .titlebox {
            text-align: center;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .titlebox h3 {
            margin: 0;
            font-size: 24px;
            color: #333;
        }
        .titlebox p {
            margin: 10px 0 0;
            color: #666;
        }
        .formbox {
            width: 50%;
            margin: 0 auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .input_mid {
            margin: 15px 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .input_mid input {
            width: calc(100% - 100px);
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .clickbox {
            text-align: center;
            margin-top: 20px;
        }
        .clickbox input[type="submit"],
        .clickbox input[type="reset"] {
            background-color: #4CAF50;
            color: white;
            padding: 12px 20px;
            margin: 8px 5px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .clickbox input[type="submit"]:hover,
        .clickbox input[type="reset"]:hover {
            opacity: 0.8;
        }
        .redbox input[type="reset"] {
            background-color: #f44336;
        }
        .resultbox {
            width: 90%;
            margin: 20px auto;
        }
        iframe {
            width: 100%;
            height: 500px;
            border: none;
            border-radius: 4px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            display: block;
        }
    </style>
</head>
<body>

<div class="titlebox">
    <h3>选课管理 >> 重修管理</h3>
    <p>使用提示：在这里你可以管理重修的学生。下面的选项可以模糊搜索。</p>
</div>

<div class="formbox">
    <form action="./fun/getRetake.php" method="get" target="resultbox">
        <div class="input_mid">学号<input name="sid" type="text"></div>
        <div class="input_mid">学生姓名<input name="name" type="text"></div>
        <div class="input_mid">课程号<input name="cid" type="text"></div>
        <div class="input_mid">课程名<input name="cname" type="text"></div>
        <div class="clickbox clearfloat greenbox firstbox"><input name="submit" type="submit" value="提交"></div>
        <div class="redbox clickbox"><input name="reset" type="reset" value="清除"></div>
    </form>
</div>

<div class="resultbox">
    <iframe name="resultbox" frameborder="0"></iframe>
</div>

</body>
</html>
